var user = 'hello';

function hello(message){
    console.log(message);
}

module.exports.me = hello;
exports.user1 = user;
 
 var user = require('./Controller/useer');
 user.user1
 var c = user.user1;
 console.log(c);

 user.me('node');
